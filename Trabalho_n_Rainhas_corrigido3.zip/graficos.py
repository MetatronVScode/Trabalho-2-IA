import csv

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

CORES = {'A*': '#1f4e9c', 'Busca Gulosa': '#d9822b', 'Gulosa local (min-conflicts)': '#3a9a5b'}


def _ler(nome):
    with open(nome, encoding='utf-8') as f:
        return list(csv.DictReader(f))


# gráfico de barras em escala log; hachurado = não resolveu
def _barras(linhas, campo, titulo, rotulo_y, arquivo):
    ns = [8, 80, 800]
    larg = 0.26
    fig, ax = plt.subplots(figsize=(8, 4.4), dpi=200)
    for i, alg in enumerate(CORES):
        for j, n in enumerate(ns):
            r = next(x for x in linhas if x['algoritmo'] == alg and int(x['n']) == n)
            v = max(float(r[campo]), 1e-4 if campo == 'tempo_s' else 1)
            ok = r['sucesso'] == 'True'
            x = j + (i - 1) * larg
            ax.bar(x, v, larg * 0.92, color=CORES[alg], hatch='' if ok else '///',
                   edgecolor='black' if not ok else CORES[alg], linewidth=0.6, label=alg if j == 0 else None)
            ax.text(x, v * 1.15, ('%.4g' % float(r[campo])) + ('' if ok else '*'), ha='center', va='bottom', fontsize=7)
    ax.set_yscale('log')
    ax.set_xticks(range(len(ns)))
    ax.set_xticklabels([f'n = {n}' for n in ns])
    ax.set_ylabel(rotulo_y)
    ax.set_title(titulo, fontsize=11)
    ax.grid(axis='y', alpha=0.3, which='major')
    ax.set_ylim(top=ax.get_ylim()[1] * 4)
    h, l = ax.get_legend_handles_labels()
    ax.legend(h, l, fontsize=8, loc='upper left', ncol=3)
    fig.text(0.01, 0.01, '* barra hachurada: não encontrou solução (limite de tempo ou de memória atingido)',
             fontsize=6.5, color='#444')
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(arquivo)
    plt.close(fig)


def gerar(csv_principal='resultados.csv'):
    linhas = _ler(csv_principal)
    _barras(linhas, 'tempo_s', 'Tempo de execução por algoritmo e tamanho', 'tempo (s, escala log)', 'grafico_tempo.png')
    _barras(linhas, 'expandidos', 'Passos por algoritmo e tamanho', 'passos (escala log)', 'grafico_passos.png')
    print('Gráficos grafico_tempo.png e grafico_passos.png criados.')


if __name__ == '__main__':
    gerar()
