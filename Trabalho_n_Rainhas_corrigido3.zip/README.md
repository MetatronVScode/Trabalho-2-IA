TRABALHO DE IA - N-RAINHAS (A* e Busca Gulosa)

Arquivos
- n_rainhas.py ........ programa (A*, Busca Gulosa e min-conflicts de referência)
- graficos.py ......... gera grafico_tempo.png e grafico_passos.png a partir dos CSVs
- relatorio.pdf / .tex / .docx  relatório no formato SBC (o .docx imita o estilo SBC no Word)
- sbc-template.sty .... APROXIMAÇÃO do estilo SBC, só para compilar fora do Overleaf.
                        Para usar o oficial, baixe o pacote da SBC e substitua este arquivo.
- resultados*.csv ..... dados dos experimentos

Requisitos: Python 3.9+, numpy, matplotlib   (pip install numpy matplotlib)

Executar
  python n_rainhas.py 8 --algoritmo astar
  python n_rainhas.py 8 --algoritmo gulosa
  python n_rainhas.py 6 --algoritmo astar --formulacao livre
  python n_rainhas.py --experimentos          (refaz CSVs e gráficos, ~1 min)

Compilar o relatório: pdflatex relatorio.tex (duas vezes)
No Overleaf: abra o template SBC, substitua o main.tex pelo relatorio.tex e envie os dois PNG.
