#!/usr/bin/env python3
# n-Rainhas com A*, Busca Gulosa e min-conflicts (referência)
# Uso: python n_rainhas.py 8 --algoritmo astar | gulosa | minconflicts
#      python n_rainhas.py --experimentos
import argparse
import csv
import heapq
import itertools
import random
import time
from collections import Counter

import numpy as np

LIMITE_SEGUNDOS = 15.0
LIMITE_FRONTEIRA = 3_000_000


# h(s): pares de rainhas que se atacam (linha, coluna ou diagonal)
def conflitos(posicoes):
    linhas, colunas, d1, d2 = Counter(), Counter(), Counter(), Counter()
    for r, c in posicoes:
        linhas[r] += 1
        colunas[c] += 1
        d1[r - c] += 1
        d2[r + c] += 1
    pares = lambda cont: sum(v * (v - 1) // 2 for v in cont.values())
    return pares(linhas) + pares(colunas) + pares(d1) + pares(d2)


# confere se a solução tem n casas distintas e nenhum conflito
def validar(sol, n):
    return (sol is not None and len(sol) == n and len(set(sol)) == n
            and all(0 <= r < n and 0 <= c < n for r, c in sol) and conflitos(sol) == 0)


class Resultado:
    def __init__(self, solucao, expandidos, gerados, tempo, fronteira_max, motivo):
        self.solucao = solucao
        self.expandidos = expandidos
        self.gerados = gerados
        self.tempo = tempo
        self.fronteira_max = fronteira_max
        self.motivo = motivo  # solucao | tempo | memoria | esgotada

    @property
    def sucesso(self):
        return self.motivo == 'solucao'


# colunas das rainhas do caminho raiz -> nó
def _caminho(pai, coluna, no):
    cols = []
    while pai[no] != -1:
        cols.append(coluna[no])
        no = pai[no]
    cols.reverse()
    return cols


# A* (f = g + h) ou Gulosa (f = h), uma rainha por linha
def busca_linha(n, metodo, limite_s=LIMITE_SEGUNDOS, limite_front=LIMITE_FRONTEIRA, semente=0, poda=True):
    rng = random.Random(semente)
    t0 = time.perf_counter()
    pai, coluna, prof, hval = [-1], [-1], [0], [0]
    fronteira = [(0, 0, 0, 0)]
    expandidos, gerados, fronteira_max = 0, 1, 1
    idx = np.arange(n)

    while fronteira:
        if time.perf_counter() - t0 >= limite_s:
            return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'tempo')
        if len(fronteira) >= limite_front:
            return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'memoria')

        *_, no = heapq.heappop(fronteira)
        k = prof[no]
        if k == n and hval[no] == 0:
            cols = _caminho(pai, coluna, no)
            sol = tuple((r, c) for r, c in enumerate(cols))
            return Resultado(sol, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'solucao')
        if k == n:
            continue

        expandidos += 1
        cols = np.array(_caminho(pai, coluna, no), dtype=np.int64)
        linhas = np.arange(k)
        cc = np.bincount(cols, minlength=n)
        d1 = np.bincount(linhas - cols + n - 1, minlength=2 * n)
        d2 = np.bincount(linhas + cols, minlength=2 * n)
        # conflitos novos de uma rainha em (k, c), para cada coluna c
        novos = cc + d1[k - idx + n - 1] + d2[k + idx]
        h_filhos = hval[no] + novos

        ordem = list(range(n))
        if metodo == 'gulosa':
            rng.shuffle(ordem)  # desempate aleatório entre irmãos

        for c in ordem:
            h = int(h_filhos[c])
            if poda and h > 0:
                continue  # h nunca diminui: estado sem saída
            pai.append(no)
            coluna.append(c)
            prof.append(k + 1)
            hval.append(h)
            nid = len(pai) - 1
            g = k + 1
            chave = (g + h, h, -g, nid) if metodo == 'astar' else (h, -g, nid)
            heapq.heappush(fronteira, chave)
            gerados += 1
        fronteira_max = max(fronteira_max, len(fronteira))

    return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'esgotada')


# formulação literal: rainha em qualquer casa vazia
def busca_livre(n, metodo, limite_s=LIMITE_SEGUNDOS, limite_front=LIMITE_FRONTEIRA):
    t0 = time.perf_counter()
    vazio = tuple()
    fronteira = [(0, 0, 0, 0, vazio)]
    visitados = {vazio}
    cont = itertools.count(1)
    expandidos, gerados, fronteira_max = 0, 1, 1
    while fronteira:
        if time.perf_counter() - t0 >= limite_s:
            return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'tempo')
        if len(fronteira) >= limite_front:
            return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'memoria')
        *_, estado = heapq.heappop(fronteira)
        if len(estado) == n and conflitos(estado) == 0:
            return Resultado(estado, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'solucao')
        if len(estado) >= n:
            continue
        expandidos += 1
        ocupadas = set(estado)
        for r in range(n):
            for c in range(n):
                if (r, c) in ocupadas:
                    continue
                novo = tuple(sorted(estado + ((r, c),)))
                if novo in visitados:
                    continue
                visitados.add(novo)
                h, g = conflitos(novo), len(novo)
                chave = (g + h, h, -g) if metodo == 'astar' else (h, -g, 0)
                heapq.heappush(fronteira, (*chave, next(cont), novo))
                gerados += 1
        fronteira_max = max(fronteira_max, len(fronteira))
    return Resultado(None, expandidos, gerados, time.perf_counter() - t0, fronteira_max, 'esgotada')


# busca local gulosa (referência): move uma rainha em conflito para a coluna com menos ataques
def min_conflicts(n, limite_s=LIMITE_SEGUNDOS, max_passos=100_000, reinicios=10, semente=42):
    rng = random.Random(semente)
    t0 = time.perf_counter()
    total = 0
    for _ in range(reinicios):
        cols = [rng.randrange(n) for _ in range(n)]
        for passo in range(max_passos):
            if time.perf_counter() - t0 >= limite_s:
                break
            cc = Counter(cols)
            d1 = Counter(r - cols[r] for r in range(n))
            d2 = Counter(r + cols[r] for r in range(n))
            por_rainha = [(cc[cols[r]] - 1) + (d1[r - cols[r]] - 1) + (d2[r + cols[r]] - 1) for r in range(n)]
            h = sum(por_rainha) // 2
            if h == 0:
                sol = tuple((r, cols[r]) for r in range(n))
                return Resultado(sol, total, total, time.perf_counter() - t0, 0, 'solucao')
            total += 1
            linha = rng.choice([r for r, v in enumerate(por_rainha) if v > 0])
            pont = [cc[c] + d1[linha - c] + d2[linha + c] for c in range(n)]
            pont[cols[linha]] -= 3  # tira a própria rainha da conta
            menor = min(pont)
            cols[linha] = rng.choice([c for c, v in enumerate(pont) if v == menor])
        if time.perf_counter() - t0 >= limite_s:
            break
    estourou = time.perf_counter() - t0 >= limite_s
    return Resultado(None, total, total, time.perf_counter() - t0, 0, 'tempo' if estourou else 'esgotada')


MOTIVOS = {'solucao': 'solução encontrada', 'tempo': 'limite de tempo atingido',
           'memoria': 'limite de memória (fronteira) atingido', 'esgotada': 'fronteira esgotada'}
NOMES = {'astar': 'A*', 'gulosa': 'Busca Gulosa', 'minconflicts': 'Gulosa local (min-conflicts)'}


def resolver(n, algoritmo, formulacao='linha', limite_s=LIMITE_SEGUNDOS, poda=True, semente=42):
    if n < 1:
        raise ValueError('n deve ser um inteiro positivo.')
    if algoritmo == 'minconflicts':
        return min_conflicts(n, limite_s, semente=semente)
    if formulacao == 'livre':
        return busca_livre(n, algoritmo, limite_s)
    return busca_linha(n, algoritmo, limite_s, semente=semente, poda=poda)


# roda um caso, imprime o resumo e devolve uma linha para o CSV
def executar(n, algoritmo, formulacao='linha', limite_s=LIMITE_SEGUNDOS, poda=True, semente=42, imprimir=True):
    res = resolver(n, algoritmo, formulacao, limite_s, poda, semente)
    ok = res.sucesso and validar(res.solucao, n)
    if algoritmo == 'minconflicts':
        variante = 'busca local'
    elif formulacao == 'livre':
        variante = 'livre (qualquer casa vazia)'
    else:
        variante = 'linha' + (' com poda' if poda else ' sem poda')
    if imprimir:
        print(f'Algoritmo : {NOMES[algoritmo]}  [{variante}]')
        print(f'n         : {n}')
        print(f'Resultado : {MOTIVOS[res.motivo]}')
        print(f'Expandidos: {res.expandidos}   Gerados: {res.gerados}   Fronteira máx.: {res.fronteira_max}')
        print(f'Tempo (s) : {res.tempo:.4f}')
        if ok:
            print('Solução válida (conflitos = 0): sim')
            if n <= 30:
                pos = dict(res.solucao)
                for r in range(n):
                    print(' '.join('Q' if pos[r] == c else '.' for c in range(n)))
            else:
                print('Tabuleiro omitido na tela (n > 30).')
    return {'algoritmo': NOMES[algoritmo], 'variante': variante, 'n': n, 'semente': semente, 'sucesso': ok,
            'expandidos': res.expandidos, 'gerados': res.gerados, 'fronteira_max': res.fronteira_max,
            'tempo_s': round(res.tempo, 4), 'resultado': MOTIVOS[res.motivo]}


CAMPOS = ['algoritmo', 'variante', 'n', 'semente', 'sucesso', 'expandidos', 'gerados',
          'fronteira_max', 'tempo_s', 'resultado']


def _gravar(nome, linhas):
    with open(nome, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS)
        w.writeheader()
        w.writerows(linhas)


def experimentos(limite_s=LIMITE_SEGUNDOS):
    # principal: n = 8, 80 e 800
    principal = []
    for n in (8, 80, 800):
        for alg in ('astar', 'gulosa', 'minconflicts'):
            print('\n' + '=' * 60)
            principal.append(executar(n, alg, 'linha', limite_s))
    _gravar('resultados.csv', principal)

    # formulação literal x por linha, com e sem poda
    comp = []
    for n in (4, 5, 6):
        for alg in ('astar', 'gulosa'):
            comp.append(executar(n, alg, 'livre', limite_s, imprimir=False))
    for n in (6, 8):
        for alg in ('astar', 'gulosa'):
            comp.append(executar(n, alg, 'linha', limite_s, poda=False, imprimir=False))
    for n in (6, 8):
        for alg in ('astar', 'gulosa'):
            comp.append(executar(n, alg, 'linha', limite_s, poda=True, imprimir=False))
    _gravar('resultados_formulacoes.csv', comp)

    # robustez: 10 sementes por caso
    sem = []
    for n in (8, 80, 800):
        for alg in ('gulosa', 'minconflicts'):
            for semente in range(10):
                sem.append(executar(n, alg, 'linha', 5.0, semente=semente, imprimir=False))
    _gravar('resultados_sementes.csv', sem)
    print('\nArquivos resultados*.csv criados.')
    try:
        from graficos import gerar
        gerar()
    except ImportError:
        print('graficos.py não encontrado: gráficos não gerados.')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Problema das n-Rainhas com A* e Busca Gulosa')
    p.add_argument('n', nargs='?', type=int, help='quantidade de rainhas')
    p.add_argument('--algoritmo', choices=['astar', 'gulosa', 'minconflicts'], default='gulosa')
    p.add_argument('--formulacao', choices=['linha', 'livre'], default='linha')
    p.add_argument('--sem-poda', action='store_true', help='não descarta sucessores com h > 0')
    p.add_argument('--semente', type=int, default=42)
    p.add_argument('--tempo', type=float, default=LIMITE_SEGUNDOS, help='limite de tempo (s)')
    p.add_argument('--experimentos', action='store_true', help='roda tudo e gera CSVs e gráficos')
    a = p.parse_args()
    if a.experimentos:
        experimentos(a.tempo)
    elif a.n is not None:
        if a.n < 1:
            p.error('n deve ser um inteiro positivo.')
        executar(a.n, a.algoritmo, a.formulacao, a.tempo, not a.sem_poda, a.semente)
    else:
        p.print_help()
